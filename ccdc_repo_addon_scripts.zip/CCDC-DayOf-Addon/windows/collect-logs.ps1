#requires -RunAsAdministrator
<#
CCDC Windows Log Collection
Exports common event logs + copies Defender support logs and firewall log (if present).
#>

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$out = "C:\CCDC\logs_$ts"
New-Item -ItemType Directory -Path $out -Force | Out-Null

wevtutil epl Security "$out\Security.evtx"
wevtutil epl System "$out\System.evtx"
wevtutil epl Application "$out\Application.evtx"

# Defender logs (if present)
$def = "C:\ProgramData\Microsoft\Windows Defender\Support"
if (Test-Path $def) { Copy-Item "$def\*" $out -Recurse -Force -ErrorAction SilentlyContinue }

# Firewall log path (may vary)
$fw = "$env:SystemRoot\System32\LogFiles\Firewall\pfirewall.log"
if (Test-Path $fw) { Copy-Item $fw $out -Force }

Write-Host "Logs collected to $out"
