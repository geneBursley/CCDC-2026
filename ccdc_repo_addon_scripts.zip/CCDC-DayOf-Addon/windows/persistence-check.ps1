#requires -RunAsAdministrator
<#
CCDC Windows Persistence Check
Looks for common persistence: local admin changes, new services, non-Microsoft scheduled tasks, Run keys.
#>

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$out = "C:\CCDC\persist_$ts"
New-Item -ItemType Directory -Path $out -Force | Out-Null

"== Local Administrators ==" | Out-File "$out\admins.txt"
Get-LocalGroupMember -Group "Administrators" | Out-String | Out-File "$out\admins.txt" -Append

"== Services (All) ==" | Out-File "$out\services_all.txt"
Get-CimInstance Win32_Service | Select-Object Name,DisplayName,StartMode,State,PathName |
  Sort-Object Name | Out-String | Out-File "$out\services_all.txt"

"== Scheduled Tasks (Non-Microsoft) ==" | Out-File "$out\tasks_nonms.txt"
Get-ScheduledTask | Where-Object {$_.TaskPath -notlike "\Microsoft*"} |
  Select-Object TaskName,TaskPath,State |
  Format-Table -Auto | Out-String | Out-File "$out\tasks_nonms.txt"

"== Run Keys ==" | Out-File "$out\runkeys.txt"
$runPaths = @(
  "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
  "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
  "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
  "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
)
foreach ($p in $runPaths) {
  "---- $p ----" | Out-File "$out\runkeys.txt" -Append
  try { Get-ItemProperty -Path $p | Out-String | Out-File "$out\runkeys.txt" -Append } catch { "N/A" | Out-File "$out\runkeys.txt" -Append }
}

Write-Host "Persistence snapshot written to $out"
