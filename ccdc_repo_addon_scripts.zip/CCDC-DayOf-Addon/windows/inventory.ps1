#requires -RunAsAdministrator
<#
CCDC Windows Inventory
Outputs basic host, users/admins, listening ports, running services, non-Microsoft scheduled tasks, Defender status.
#>

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$out = "C:\CCDC\inventory_$ts"
New-Item -ItemType Directory -Path $out -Force | Out-Null

"== Host ==" | Out-File "$out\host.txt"
hostname | Out-File "$out\host.txt" -Append
Get-ComputerInfo | Out-File "$out\host.txt" -Append

"== Users & Admins ==" | Out-File "$out\users.txt"
Get-LocalUser | Sort-Object Name | Format-Table Name,Enabled,LastLogon | Out-String | Out-File "$out\users.txt"
"--- Local Administrators ---" | Out-File "$out\users.txt" -Append
Get-LocalGroupMember -Group "Administrators" | Out-String | Out-File "$out\users.txt" -Append

"== Network Listening Ports ==" | Out-File "$out\net.txt"
Get-NetTCPConnection -State Listen | Sort-Object LocalPort |
  Select-Object LocalAddress,LocalPort,OwningProcess |
  Format-Table -Auto | Out-String | Out-File "$out\net.txt"

"== Services (Running) ==" | Out-File "$out\services.txt"
Get-Service | Where-Object {$_.Status -eq "Running"} | Sort-Object Name |
  Format-Table Name,DisplayName,StartType | Out-String | Out-File "$out\services.txt"

"== Scheduled Tasks (Non-Microsoft) ==" | Out-File "$out\tasks.txt"
Get-ScheduledTask | Where-Object {$_.TaskPath -notlike "\Microsoft*"} |
  Select-Object TaskName,TaskPath,State |
  Format-Table -Auto | Out-String | Out-File "$out\tasks.txt"

"== Defender Status ==" | Out-File "$out\defender.txt"
try { Get-MpComputerStatus | Out-String | Out-File "$out\defender.txt" } catch { "Defender cmdlets unavailable" | Out-File "$out\defender.txt" }

Write-Host "Inventory written to $out"
