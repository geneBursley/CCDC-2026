#requires -RunAsAdministrator
<#
CCDC Windows Baseline
Creates a simple JSON baseline: users, admins, listening ports, running services, tasks (non-MS).
#>

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$outDir = "C:\CCDC\baseline"
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$out = Join-Path $outDir "baseline_$ts.json"

$baseline = [ordered]@{
  timestamp = (Get-Date).ToString("o")
  hostname  = $env:COMPUTERNAME
  users     = (Get-LocalUser | Select-Object Name,Enabled,LastLogon)
  admins    = (Get-LocalGroupMember -Group "Administrators" | Select-Object Name,ObjectClass,PrincipalSource)
  listening = (Get-NetTCPConnection -State Listen | Select-Object LocalAddress,LocalPort,OwningProcess)
  services_running = (Get-Service | Where-Object {$_.Status -eq "Running"} | Select-Object Name,DisplayName,StartType)
  tasks_non_ms = (Get-ScheduledTask | Where-Object {$_.TaskPath -notlike "\Microsoft*"} | Select-Object TaskName,TaskPath,State)
}

$baseline | ConvertTo-Json -Depth 5 | Out-File $out -Encoding utf8
Write-Host "Baseline written to $out"
