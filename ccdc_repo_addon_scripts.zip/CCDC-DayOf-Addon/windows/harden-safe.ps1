#requires -RunAsAdministrator
<#
CCDC Windows Safe Hardening (Cautious Defaults)
- Enables Windows Firewall profiles (if disabled)
- Disables SMBv1 (common legacy risk)
- Enables Defender real-time protection (if available)
NOTE: Do NOT disable services/protocols you need for scoring. Review before running.
#>

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$out = "C:\CCDC\harden_$ts"
New-Item -ItemType Directory -Path $out -Force | Out-Null

"== Firewall status BEFORE ==" | Out-File "$out\firewall.txt"
Get-NetFirewallProfile | Out-String | Out-File "$out\firewall.txt" -Append

Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True

"== Firewall status AFTER ==" | Out-File "$out\firewall.txt" -Append
Get-NetFirewallProfile | Out-String | Out-File "$out\firewall.txt" -Append

"== Disable SMBv1 ==" | Out-File "$out\smbv1.txt"
try {
  Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart -ErrorAction Stop | Out-String | Out-File "$out\smbv1.txt"
} catch {
  $_ | Out-String | Out-File "$out\smbv1.txt" -Append
}

"== Defender RealTime Protection ==" | Out-File "$out\defender.txt"
try {
  Set-MpPreference -DisableRealtimeMonitoring $false
  Get-MpComputerStatus | Out-String | Out-File "$out\defender.txt" -Append
} catch {
  "Defender cmdlets unavailable or policy-restricted." | Out-File "$out\defender.txt" -Append
}

Write-Host "Safe hardening complete. Outputs in $out"
