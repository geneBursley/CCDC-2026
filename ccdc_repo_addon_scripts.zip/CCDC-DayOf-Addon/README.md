# CCDC Script Pack (Quick Ops)

This pack is designed for *defense + visibility* during competition.

## Suggested order of operations
1. **Inventory** (confirm what's running, what's exposed)
2. **Baseline** (save state)
3. **Persistence check** (look for new/odd accounts, tasks, services)
4. **Collect logs** (evidence + later analysis)
5. **Safe hardening** (only after confirming service requirements)

## Contents
- `windows/` PowerShell scripts (run PowerShell as Administrator where noted)
- `linux/` Bash scripts (use `sudo` where needed)
- `common/` Shared templates (allowlists, notes)

## Tips
- Prefer running inventory first on every host to avoid breaking scoring services.
- Store outputs in a writable path (Windows defaults to `C:\CCDC\...`, Linux defaults to `/tmp/...`).
