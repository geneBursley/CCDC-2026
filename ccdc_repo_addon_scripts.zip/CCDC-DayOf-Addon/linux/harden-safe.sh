#!/usr/bin/env bash
set -euo pipefail

# CCDC Linux Safe Hardening (cautious)
# - SSH: disable root login; set MaxAuthTries; enable PubkeyAuthentication; keep PasswordAuthentication as-is unless you change it intentionally
# - UFW: enable if installed (won't install)
# Creates a backup of sshd_config before modifications.

if [[ $EUID -ne 0 ]]; then
  echo "Run as root (sudo)."
  exit 1
fi

TS="$(date +%Y%m%d_%H%M%S)"
OUT="/tmp/ccdc_harden_${TS}"
mkdir -p "$OUT"

SSHD="/etc/ssh/sshd_config"
if [[ -f "$SSHD" ]]; then
  cp -a "$SSHD" "$OUT/sshd_config.bak"

  # Ensure directives exist (replace if present; append if missing)
  set_kv () {
    local key="$1" val="$2"
    if grep -qE "^\s*${key}\s+" "$SSHD"; then
      sed -i "s/^\s*${key}\s\+.*/${key} ${val}/" "$SSHD"
    else
      echo "${key} ${val}" >> "$SSHD"
    fi
  }

  set_kv "PermitRootLogin" "no"
  set_kv "MaxAuthTries" "3"
  set_kv "PubkeyAuthentication" "yes"

  # Validate config and reload
  if sshd -t 2> "$OUT/sshd_validate.txt"; then
    systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || true
  else
    echo "sshd_config validation failed. Restoring backup." | tee "$OUT/restore.txt"
    cp -a "$OUT/sshd_config.bak" "$SSHD"
  fi
fi

if command -v ufw >/dev/null 2>&1; then
  ufw status verbose > "$OUT/ufw_before.txt" || true
  ufw --force enable || true
  ufw status verbose > "$OUT/ufw_after.txt" || true
fi

echo "Safe hardening complete. Outputs: $OUT"
