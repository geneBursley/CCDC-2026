#!/usr/bin/env bash
set -euo pipefail

TS="$(date +%Y%m%d_%H%M%S)"
OUT="/tmp/ccdc_persist_${TS}"
mkdir -p "$OUT"

echo "== Crontabs (system + users) ==" > "$OUT/cron.txt"
ls -la /etc/cron.* /var/spool/cron 2>/dev/null >> "$OUT/cron.txt" || true
for u in $(cut -d: -f1 /etc/passwd); do
  crontab -l -u "$u" 2>/dev/null | sed "s/^/[$u] /" >> "$OUT/cron.txt" || true
done

echo "== systemd services/units ==" > "$OUT/systemd.txt"
if command -v systemctl >/dev/null 2>&1; then
  systemctl list-unit-files --type=service >> "$OUT/systemd.txt" || true
  systemctl list-units --type=service --all >> "$OUT/systemd.txt" || true
fi

echo "== SSH authorized_keys snapshot ==" > "$OUT/ssh_keys.txt"
for d in /home/* /root; do
  if [[ -d "$d/.ssh" ]]; then
    echo "---- $d ----" >> "$OUT/ssh_keys.txt"
    ls -la "$d/.ssh" >> "$OUT/ssh_keys.txt" 2>/dev/null || true
    [[ -f "$d/.ssh/authorized_keys" ]] && cat "$d/.ssh/authorized_keys" >> "$OUT/ssh_keys.txt" || true
    echo "" >> "$OUT/ssh_keys.txt"
  fi
done

echo "Persistence snapshot in $OUT"
