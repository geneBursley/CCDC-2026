#!/usr/bin/env bash
set -euo pipefail

TS="$(date +%Y%m%d_%H%M%S)"
OUT="/tmp/ccdc_inventory_${TS}"
mkdir -p "$OUT"

{
  echo "== Host =="
  hostname
  uname -a
  if command -v lsb_release >/dev/null 2>&1; then lsb_release -a; fi
} > "$OUT/host.txt" 2>/dev/null || true

echo "== Users with shells ==" > "$OUT/users.txt"
awk -F: '($7 !~ /nologin|false/){print $1 " -> " $7}' /etc/passwd >> "$OUT/users.txt"

echo "== Sudoers (quick) ==" > "$OUT/sudo.txt"
grep -R "ALL" /etc/sudoers /etc/sudoers.d 2>/dev/null >> "$OUT/sudo.txt" || true

echo "== Listening ports ==" > "$OUT/net.txt"
if command -v ss >/dev/null 2>&1; then ss -tulpn >> "$OUT/net.txt"; else netstat -tulpn >> "$OUT/net.txt"; fi

echo "== Services (systemd running) ==" > "$OUT/services.txt"
if command -v systemctl >/dev/null 2>&1; then
  systemctl list-units --type=service --state=running >> "$OUT/services.txt" || true
fi

echo "Wrote inventory to $OUT"
