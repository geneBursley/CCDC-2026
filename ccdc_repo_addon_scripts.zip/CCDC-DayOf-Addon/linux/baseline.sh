#!/usr/bin/env bash
set -euo pipefail

TS="$(date +%Y%m%d_%H%M%S)"
OUT="/tmp/ccdc_baseline_${TS}.json"

hostname_fqdn="$(hostname 2>/dev/null || true)"
kernel="$(uname -a 2>/dev/null || true)"

users="$(awk -F: '($7 !~ /nologin|false/){print $1}' /etc/passwd | tr '\n' ',' | sed 's/,$//')"
listening="$( (command -v ss >/dev/null 2>&1 && ss -tulpn) || netstat -tulpn 2>/dev/null || true )"

cat > "$OUT" <<EOF
{
  "timestamp": "$(date -Iseconds)",
  "hostname": "${hostname_fqdn}",
  "kernel": "${kernel}",
  "users_with_shells_csv": "${users}",
  "listening_ports_raw": $(python3 - <<PY
import json,sys
data=sys.stdin.read()
print(json.dumps(data))
PY
<<< "$listening")
}
EOF

echo "Baseline written to $OUT"
