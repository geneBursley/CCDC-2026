#!/usr/bin/env bash
set -euo pipefail

TS="$(date +%Y%m%d_%H%M%S)"
OUT="/tmp/ccdc_logs_${TS}"
mkdir -p "$OUT"

for f in /var/log/auth.log /var/log/secure /var/log/syslog /var/log/messages; do
  [[ -f "$f" ]] && cp -a "$f" "$OUT/" || true
done

if command -v journalctl >/dev/null 2>&1; then
  journalctl --since "24 hours ago" > "$OUT/journal_last24h.txt" || true
fi

[[ -f /etc/ssh/sshd_config ]] && cp -a /etc/ssh/sshd_config "$OUT/" || true

echo "Collected logs to $OUT"
