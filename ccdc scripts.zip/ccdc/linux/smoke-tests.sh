#!/usr/bin/env bash
set -euo pipefail

# CCDC Linux Smoke Tests (functional checks)
# Edit targets to match the packet/service list.
# Output: /tmp/ccdc_smoketests_<timestamp>/results.txt

TS="$(date +%Y%m%d_%H%M%S)"
OUT="/tmp/ccdc_smoketests_${TS}"
mkdir -p "$OUT"
R="$OUT/results.txt"

log(){ echo "$1" | tee -a "$R"; }

log "CCDC Smoke Tests - $(date -Iseconds)"

# === EDIT THESE TARGETS ===
HTTP_URLS=("http://localhost/")
HTTPS_URLS=("https://localhost/")
DNS_SERVER="127.0.0.1"
DNS_NAME="localhost"
CHECK_PORTS=(
  "SMTP 127.0.0.1 25"
  "POP3 127.0.0.1 110"
  "SSH 127.0.0.1 22"
  "SQL 127.0.0.1 1433"
  "FTP 127.0.0.1 21"
)

# HTTP/HTTPS functional fetch
for u in "${HTTP_URLS[@]}"; do
  if command -v curl >/dev/null 2>&1; then
    code="$(curl -s -o /dev/null -m 5 -w "%{http_code}" "$u" || true)"
    [[ "$code" =~ ^2|3 ]] && log "HTTP $u | OK | code=$code" || log "HTTP $u | FAIL | code=$code"
  else
    log "HTTP $u | FAIL | curl not installed"
  fi
done

for u in "${HTTPS_URLS[@]}"; do
  if command -v curl >/dev/null 2>&1; then
    code="$(curl -k -s -o /dev/null -m 5 -w "%{http_code}" "$u" || true)"
    [[ "$code" =~ ^2|3 ]] && log "HTTPS $u | OK | code=$code" || log "HTTPS $u | FAIL | code=$code"
  else
    log "HTTPS $u | FAIL | curl not installed"
  fi
done

# DNS query
if command -v dig >/dev/null 2>&1; then
  if dig @"$DNS_SERVER" "$DNS_NAME" +time=2 +tries=1 >/dev/null 2>&1; then
    log "DNS $DNS_SERVER -> $DNS_NAME | OK"
  else
    log "DNS $DNS_SERVER -> $DNS_NAME | FAIL"
  fi
elif command -v nslookup >/dev/null 2>&1; then
  if nslookup "$DNS_NAME" "$DNS_SERVER" >/dev/null 2>&1; then
    log "DNS $DNS_SERVER -> $DNS_NAME | OK"
  else
    log "DNS $DNS_SERVER -> $DNS_NAME | FAIL"
  fi
else
  log "DNS | FAIL | dig/nslookup not installed"
fi

# Connectivity checks (functional auth tests are environment-specific)
for entry in "${CHECK_PORTS[@]}"; do
  svc="$(awk '{print $1}' <<<"$entry")"
  host="$(awk '{print $2}' <<<"$entry")"
  port="$(awk '{print $3}' <<<"$entry")"
  if command -v nc >/dev/null 2>&1; then
    if nc -z -w 3 "$host" "$port" >/dev/null 2>&1; then
      log "$svc $host:$port | OK"
    else
      log "$svc $host:$port | FAIL"
    fi
  else
    # fallback: bash /dev/tcp
    if timeout 3 bash -c ">/dev/tcp/$host/$port" >/dev/null 2>&1; then
      log "$svc $host:$port | OK"
    else
      log "$svc $host:$port | FAIL"
    fi
  fi
done

echo "Results: $R"
