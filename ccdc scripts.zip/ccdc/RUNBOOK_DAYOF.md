# CCDC Day-Of Execution Runbook

## North Star
Keep **critical services functional** and avoid **SLA violations** while you work injects and contain Red Team activity.

## Roles (minimum viable)
- **Captain/Traffic Control**: triage, tasking, time boxing, scoreboard watch.
- **Service Owner(s)**: 1 per critical service (Web, Mail, DNS, DB, etc.).
- **IR/Logging**: alerts, log pulls, evidence, persistence hunting.
- **Inject/Orange Team Liaison**: customer service, written responses, tracking.

If you’re short-staffed: Captain + Service Owner + Inject Liaison.

## 0–15 minutes: Stop the bleeding without breaking scoring
1. **Get the packet + list of required services** and who owns each.
2. **Validate services are FUNCTIONAL** (not just “port open”). Use smoke tests.
3. **Run inventory + baseline** on each host.
4. **Start an inject tracker** and assign owners.

## 15–60 minutes: Stabilize
- Fix the top scoring failures first (anything failing scorebot checks).
- Patch only if it won’t take services down (time box maintenance).
- Begin persistence checks on internet-facing boxes first.

## Every 10–15 minutes: Cadence loop
- Check score/status page or service indicators (if provided).
- Run smoke tests on critical services.
- Update inject tracker status (Assigned / In Progress / Blocked / Submitted).
- Log key actions (what changed, when, why).

## Incident response loop (simple + fast)
1. Identify (symptom, host, user, service impact).
2. Contain (block IOC, disable account, stop malicious service) **without breaking critical services**.
3. Eradicate (remove persistence, patch, fix config).
4. Recover (verify functionality via smoke tests).
5. Document (for injects and after-action).

## Safe hardening rule
Don’t “harden blind.” Inventory first, confirm scoring requirements, then apply safe changes.
