#requires -RunAsAdministrator
<#
CCDC Windows Smoke Tests (functional checks)
Edit the $Targets section to match the packet/service list.
Outputs: C:\CCDC\smoketests_<timestamp>\results.txt
#>

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$outDir = "C:\CCDC\smoketests_$ts"
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$out = Join-Path $outDir "results.txt"

# === EDIT THESE TARGETS ===
$Targets = @{
  "HTTP"  = @("http://localhost/")
  "HTTPS" = @("https://localhost/")
  "DNS"   = @("127.0.0.1","localhost")   # server, query name
  "SMTP"  = @("127.0.0.1",25)            # server, port
  "POP3"  = @("127.0.0.1",110)           # server, port
  "SSH"   = @("127.0.0.1",22)            # server, port (connectivity only)
  "SQL"   = @("127.0.0.1",1433)          # server, port (connectivity only)
  "FTP"   = @("127.0.0.1",21)            # server, port (connectivity only)
}

function Write-Result($name, $ok, $detail) {
  $line = "{0} | {1} | {2}" -f $name, ($(if($ok){"OK"}else{"FAIL"})), $detail
  $line | Tee-Object -FilePath $out -Append
}

"CCDC Smoke Tests - $((Get-Date).ToString('o'))" | Out-File $out

# HTTP/HTTPS functional fetch
foreach ($url in $Targets["HTTP"]) {
  try {
    $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 5
    Write-Result "HTTP $url" $true "Status=$($r.StatusCode)"
  } catch {
    Write-Result "HTTP $url" $false $_.Exception.Message
  }
}
foreach ($url in $Targets["HTTPS"]) {
  try {
    $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 5
    Write-Result "HTTPS $url" $true "Status=$($r.StatusCode)"
  } catch {
    Write-Result "HTTPS $url" $false $_.Exception.Message
  }
}

# DNS query
try {
  $dnsServer = $Targets["DNS"][0]
  $qname = $Targets["DNS"][1]
  $ans = Resolve-DnsName -Name $qname -Server $dnsServer -ErrorAction Stop
  Write-Result "DNS $dnsServer -> $qname" $true ($ans | Select-Object -First 1 | Out-String).Trim()
} catch {
  Write-Result "DNS" $false $_.Exception.Message
}

# Connectivity checks for common services (functional auth tests are environment-specific)
$ports = @(
  @("SMTP",$Targets["SMTP"][0],[int]$Targets["SMTP"][1]),
  @("POP3",$Targets["POP3"][0],[int]$Targets["POP3"][1]),
  @("SSH",$Targets["SSH"][0],[int]$Targets["SSH"][1]),
  @("SQL",$Targets["SQL"][0],[int]$Targets["SQL"][1]),
  @("FTP",$Targets["FTP"][0],[int]$Targets["FTP"][1])
)

foreach ($p in $ports) {
  $name,$host,$port = $p
  try {
    $t = Test-NetConnection -ComputerName $host -Port $port -WarningAction SilentlyContinue
    Write-Result "$name $host:$port" $t.TcpTestSucceeded ($t | Select-Object -Property TcpTestSucceeded,RemoteAddress,RemotePort | Out-String).Trim()
  } catch {
    Write-Result "$name $host:$port" $false $_.Exception.Message
  }
}

Write-Host "Smoke test results: $out"
