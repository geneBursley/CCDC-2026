# Inject Tracker Template

Use ONE line per inject. Update every 10–15 minutes.

| Inject ID | Title | Due | Owner | Status | Notes / Next Action | Submitted? |
|---|---|---|---|---|---|---|
|  |  |  |  | New / Assigned / In Progress / Blocked / Submitted |  | Yes/No |

## Status definitions
- **New**: received, not yet assigned
- **Assigned**: owner named, starting work
- **In Progress**: active work happening
- **Blocked**: waiting on info/approval/credentials
- **Submitted**: delivered response/work product
