#!/usr/bin/env bash
# Ubuntu Ecom role overlay: tighten to web + ssh only (after verifying scoring)
set -euo pipefail
if command -v ufw >/dev/null 2>&1; then
  ufw delete allow 25/tcp || true
  ufw delete allow 110/tcp || true
  ufw delete allow 143/tcp || true
  ufw delete allow 587/tcp || true
  ufw delete allow 993/tcp || true
  ufw delete allow 995/tcp || true
  ufw delete allow 53/tcp || true
  ufw delete allow 53/udp || true
  ufw status verbose
fi
echo "[*] Ubuntu Ecom overlay applied."
