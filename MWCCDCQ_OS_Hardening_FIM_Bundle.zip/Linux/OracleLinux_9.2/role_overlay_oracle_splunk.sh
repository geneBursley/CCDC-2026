#!/usr/bin/env bash
# Oracle Linux Splunk overlay: restrict Splunk mgmt/UI to admin subnet (edit CIDR)
set -euo pipefail
ADMIN_CIDR="${ADMIN_CIDR:-10.0.0.0/24}"  # <-- set this to your admin/workstation subnet
# Common Splunk ports: 8000 (web), 8089 (mgmt), 9997 (forwarder), 514 (syslog if used)
if command -v firewall-cmd >/dev/null 2>&1; then
  firewall-cmd --permanent --remove-port=8000/tcp || true
  firewall-cmd --permanent --remove-port=8089/tcp || true
  firewall-cmd --permanent --add-rich-rule="rule family=ipv4 source address=${ADMIN_CIDR} port port=8000 protocol=tcp accept"
  firewall-cmd --permanent --add-rich-rule="rule family=ipv4 source address=${ADMIN_CIDR} port port=8089 protocol=tcp accept"
  firewall-cmd --reload
  firewall-cmd --list-all
fi
echo "[*] Splunk overlay applied (ADMIN_CIDR=${ADMIN_CIDR})."
