#!/usr/bin/env bash
# Fedora Webmail overlay: keep mail + web; restrict to required only after confirming services (postfix/dovecot/httpd/nginx)
set -euo pipefail
# Placeholders: adjust once you confirm which ports are truly needed.
echo "[*] Fedora Webmail overlay: review active listeners:"
ss -tulpen || netstat -tulpen || true
echo "[*] After confirming, remove unused firewall ports to reduce attack surface."
