#!/usr/bin/env bash
set -euo pipefail

LOG="/var/log/ccdc_hardening.log"
exec > >(tee -a "$LOG") 2>&1

echo "[*] Starting Linux hardening: $(hostname) $(date)"

# Detect distro family
. /etc/os-release
ID_LIKE="${ID_LIKE:-}"
FAMILY="unknown"
if [[ "$ID" =~ (ubuntu|debian) ]] || [[ "$ID_LIKE" =~ (debian) ]]; then
  FAMILY="debian"
elif [[ "$ID" =~ (fedora) ]]; then
  FAMILY="fedora"
elif [[ "$ID" =~ (rhel|centos|ol|rocky|almalinux) ]] || [[ "$ID_LIKE" =~ (rhel|fedora) ]]; then
  FAMILY="rhel"
fi
echo "[*] Distro: $ID ($FAMILY)"

# --- 1) Patch quickly (but safely) ---
if [[ "$FAMILY" == "debian" ]]; then
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get -y upgrade
  apt-get -y install ufw fail2ban auditd aide curl vim
elif [[ "$FAMILY" == "fedora" ]]; then
  dnf -y upgrade --refresh
  dnf -y install firewalld fail2ban audit aide curl vim
  systemctl enable --now firewalld
elif [[ "$FAMILY" == "rhel" ]]; then
  dnf -y upgrade --refresh
  dnf -y install firewalld fail2ban audit aide curl vim
  systemctl enable --now firewalld
else
  echo "[!] Unknown distro family; skipping package ops."
fi

# --- 2) SSH hardening (don’t lock yourself out) ---
SSHD="/etc/ssh/sshd_config"
if [[ -f "$SSHD" ]]; then
  cp -a "$SSHD" "${SSHD}.bak.$(date +%s)"

  # Conservative: keep password auth initially if you don’t have keys everywhere yet.
  sed -i 's/^\s*#\?\s*PermitRootLogin.*/PermitRootLogin no/' "$SSHD"
  sed -i 's/^\s*#\?\s*X11Forwarding.*/X11Forwarding no/' "$SSHD"
  sed -i 's/^\s*#\?\s*MaxAuthTries.*/MaxAuthTries 4/' "$SSHD"
  sed -i 's/^\s*#\?\s*ClientAliveInterval.*/ClientAliveInterval 300/' "$SSHD"
  sed -i 's/^\s*#\?\s*ClientAliveCountMax.*/ClientAliveCountMax 2/' "$SSHD"
  grep -q '^Protocol' "$SSHD" || echo 'Protocol 2' >> "$SSHD"

  systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null || true
  echo "[*] SSH hardened (root login disabled)."
fi

# --- 3) Local firewall baseline ---
allow_common_ports_ufw() {
  ufw --force reset
  ufw default deny incoming
  ufw default allow outgoing

  # SSH (restrict source later if possible)
  ufw allow 22/tcp

  # Web
  ufw allow 80/tcp
  ufw allow 443/tcp

  # Mail (enable only if your host provides these)
  ufw allow 25/tcp
  ufw allow 110/tcp
  ufw allow 143/tcp
  ufw allow 587/tcp
  ufw allow 993/tcp
  ufw allow 995/tcp

  # DNS
  ufw allow 53/tcp
  ufw allow 53/udp

  ufw --force enable
  ufw status verbose
}

allow_common_ports_firewalld() {
  firewall-cmd --set-default-zone=public
  firewall-cmd --permanent --remove-service=dhcpv6-client >/dev/null 2>&1 || true

  firewall-cmd --permanent --add-service=ssh
  firewall-cmd --permanent --add-service=http
  firewall-cmd --permanent --add-service=https

  firewall-cmd --permanent --add-service=smtp
  firewall-cmd --permanent --add-port=110/tcp
  firewall-cmd --permanent --add-port=143/tcp
  firewall-cmd --permanent --add-port=587/tcp
  firewall-cmd --permanent --add-port=993/tcp
  firewall-cmd --permanent --add-port=995/tcp
  firewall-cmd --permanent --add-service=dns

  firewall-cmd --reload
  firewall-cmd --list-all
}

if command -v ufw >/dev/null 2>&1; then
  echo "[*] Configuring UFW baseline..."
  allow_common_ports_ufw
elif command -v firewall-cmd >/dev/null 2>&1; then
  echo "[*] Configuring firewalld baseline..."
  allow_common_ports_firewalld
fi

# --- 4) Fail2ban quick win ---
if systemctl list-unit-files | grep -q fail2ban; then
  mkdir -p /etc/fail2ban
  cat >/etc/fail2ban/jail.d/ccdc.local <<'EOF'
[sshd]
enabled = true
maxretry = 4
findtime = 10m
bantime = 30m
EOF
  systemctl enable --now fail2ban
  fail2ban-client status sshd || true
fi

# --- 5) sysctl safe baseline ---
SYSCTL="/etc/sysctl.d/99-ccdc-hardening.conf"
cat >"$SYSCTL" <<'EOF'
net.ipv4.conf.all.rp_filter=1
net.ipv4.conf.default.rp_filter=1
net.ipv4.icmp_echo_ignore_broadcasts=1
net.ipv4.conf.all.accept_source_route=0
net.ipv4.conf.default.accept_source_route=0
net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.default.accept_redirects=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.default.send_redirects=0
kernel.kptr_restrict=2
kernel.dmesg_restrict=1
fs.protected_hardlinks=1
fs.protected_symlinks=1
EOF
sysctl --system || true

# --- 6) auditd on ---
systemctl enable --now auditd 2>/dev/null || true

echo "[*] Done: Linux hardening complete."
