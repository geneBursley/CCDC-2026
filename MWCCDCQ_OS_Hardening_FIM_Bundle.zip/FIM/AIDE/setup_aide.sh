#!/usr/bin/env bash
set -euo pipefail

echo "[*] Installing and initializing AIDE..."
if command -v apt-get >/dev/null 2>&1; then
  apt-get update && apt-get -y install aide
elif command -v dnf >/dev/null 2>&1; then
  dnf -y install aide
fi

# Copy template if desired:
# cp ./aide.conf /etc/aide/aide.conf  (path varies by distro)

# Initialize baseline
aideinit || aide --init || true

# Move DB into place (paths vary)
if [[ -f /var/lib/aide/aide.db.new.gz ]]; then
  mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz
elif [[ -f /var/lib/aide/aide.db.new ]]; then
  mv /var/lib/aide/aide.db.new /var/lib/aide/aide.db
fi

# Schedule daily check
cat >/etc/cron.d/aide-ccdc <<'EOF'
17 5 * * * root /usr/bin/aide --check | /usr/bin/logger -t AIDE
EOF

echo "[*] AIDE initialized and scheduled."
