# Compare current hashes to baseline_hashes.csv
# Usage:
#   powershell -ExecutionPolicy Bypass -File .\fim_diff.ps1 -Baseline "C:\CCDC_FIM\baseline_hashes.csv"

param(
  [Parameter(Mandatory=$true)][string]$Baseline
)

if (!(Test-Path $Baseline)) { throw "Baseline not found: $Baseline" }

$base = Import-Csv $Baseline
$results = @()

foreach ($row in $base) {
  $p = $row.Path
  $old = $row.Hash
  if (Test-Path $p) {
    try {
      $new = (Get-FileHash $p -Algorithm SHA256).Hash
      if ($new -ne $old) {
        $results += [pscustomobject]@{Path=$p; OldHash=$old; NewHash=$new; Status="CHANGED"}
      }
    } catch {
      $results += [pscustomobject]@{Path=$p; OldHash=$old; NewHash=""; Status="ERROR_HASHING"}
    }
  } else {
    $results += [pscustomobject]@{Path=$p; OldHash=$old; NewHash=""; Status="MISSING"}
  }
}

$out = Join-Path (Split-Path $Baseline) ("diff_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".csv")
$results | Export-Csv -NoTypeInformation $out
Write-Host "Diff written to $out"
