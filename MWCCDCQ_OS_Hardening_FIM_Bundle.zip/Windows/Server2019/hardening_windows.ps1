#requires -RunAsAdministrator
$Log = "C:\ccdc_hardening.log"
"[*] Starting Windows hardening $(hostname) $(Get-Date)" | Tee-Object -FilePath $Log -Append

# 1) Enable firewall (domain/private/public)
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True

# 2) Turn on key auditing (useful for IR & scoring evidence)
auditpol /set /category:* /success:enable /failure:enable | Out-Null

# 3) Defender on (best-effort; don’t break apps)
Try {
  Set-MpPreference -DisableRealtimeMonitoring $false
  Set-MpPreference -PUAProtection Enabled
} Catch {}

# 4) Disable SMBv1 (usually safe)
Try { Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart -ErrorAction SilentlyContinue } Catch {}

# 5) Create FIM baseline hashes (conservative)
$BaselineDir = "C:\CCDC_FIM"
New-Item -ItemType Directory -Path $BaselineDir -Force | Out-Null

$Targets = @(
  "C:\Windows\System32",
  "C:\inetpub\wwwroot",
  "C:\Program Files",
  "C:\Program Files (x86)"
) | Where-Object { Test-Path $_ }

$BaselineFile = Join-Path $BaselineDir "baseline_hashes.csv"
"Path,Hash" | Out-File $BaselineFile -Encoding ASCII

foreach ($t in $Targets) {
  Get-ChildItem $t -File -Recurse -ErrorAction SilentlyContinue |
    ForEach-Object {
      try {
        $h = (Get-FileHash $_.FullName -Algorithm SHA256).Hash
        ('"{0}",{1}' -f $_.FullName.Replace('"','""'), $h) | Out-File $BaselineFile -Append -Encoding ASCII
      } catch {}
    }
}

"[*] Baseline written to $BaselineFile" | Tee-Object -FilePath $Log -Append

# 6) Optional: basic service inventory
"[*] Listening ports:" | Tee-Object -FilePath $Log -Append
try { netstat -ano | findstr LISTENING | Tee-Object -FilePath $Log -Append } catch {}

"[*] Done." | Tee-Object -FilePath $Log -Append
