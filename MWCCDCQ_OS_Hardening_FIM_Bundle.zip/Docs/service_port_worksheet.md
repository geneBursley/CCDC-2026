# CCDC Service/Port Worksheet (fill during initial inventory)

> Use this to avoid breaking scoring while you harden.
> Start permissive → then restrict by *source IP* once confirmed.

## Host list (from team packet)
- Windows Server 2019 (AD/DNS)
- Windows Server 2019 (Web)
- Windows Server 2022 (FTP)
- Windows 11 Workstation
- Ubuntu 24.04 Workstation (admin jump host)
- Ubuntu 24.04 Server (Ecom)
- Fedora 40 Server (Webmail)
- Oracle Linux 9.2 Server (Splunk)
- Palo Alto Firewall (Core)
- Cisco FTD Firewall (Edge)
- VyOS Router

## Per-host: confirm listeners
Linux:
- ss -tulpen
- systemctl --type=service --state=running

Windows:
- netstat -ano | findstr LISTENING
- Get-Service | ? Status -eq Running

## Scored services (common)
- HTTP/HTTPS
- SMTP / POP3 / IMAP (as applicable)
- DNS

Fill in:
| Host | Service | Port(s) | Expected Client Source(s) | Notes |
|------|---------|---------|---------------------------|-------|
|      |         |         |                           |       |
