# MWCCDCQ Hardening + FIM Bundle

Generated: 2026-01-29

## What's inside
- Linux:
  - `Linux/hardening_linux.sh` (unified hardening baseline for Ubuntu/Fedora/RHEL-family)
  - Role overlays:
    - Ubuntu Ecom: `Linux/Ubuntu_24.04/role_overlay_ubuntu_ecom.sh`
    - Fedora Webmail: `Linux/Fedora_40/role_overlay_fedora_webmail.sh`
    - Oracle Linux Splunk: `Linux/OracleLinux_9.2/role_overlay_oracle_splunk.sh`
- Windows:
  - `hardening_windows.ps1` (copied into each Windows folder)
- FIM:
  - AIDE template + setup
  - Windows hash diff checker
  - Wazuh FIM config snippets (Linux/Windows)
- Docs:
  - Service/Port worksheet to fill out during inventory

## Quick usage
Linux:
1) scp `Linux/hardening_linux.sh` to the host
2) `sudo bash hardening_linux.sh`
3) Apply role overlay if applicable

Windows:
1) Copy `hardening_windows.ps1`
2) Run in elevated PowerShell:
   `powershell -ExecutionPolicy Bypass -File .\hardening_windows.ps1`

AIDE:
- Use `FIM/AIDE/aide.conf` as a starting template
- Run `FIM/AIDE/setup_aide.sh`

Windows FIM diff:
- `powershell -ExecutionPolicy Bypass -File .\fim_diff.ps1 -Baseline "C:\CCDC_FIM\baseline_hashes.csv"`
